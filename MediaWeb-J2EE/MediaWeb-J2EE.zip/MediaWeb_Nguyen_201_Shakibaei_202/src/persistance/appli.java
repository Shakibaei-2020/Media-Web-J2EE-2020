package persistance;

public class appli {

	public static void main(String[] args) {
		new ConnexionBD();
	}

}
